
export const getInsertionSortAnimations = array => {
    const animations = [];
    if (array.length <= 1) return array;
     InsertionSort(array,animations);
    return animations;
};

function InsertionSort(arr,animations)
{
    for(let i=1;i<arr.length;i++)
    {
        var key = arr[i];
        var j=i-1;
        animations.push([i]);
        while(j>=0 && arr[j]>key)
        {
            animations.push([j,0,0]);
            animations.push([j,0,1]);
            animations.push([j+1,arr[j]]);
            arr[j+1] = arr[j];
            j--;

        }
        arr[j+1] = key;
        animations.push([j+1,key]);
        
    }
}

