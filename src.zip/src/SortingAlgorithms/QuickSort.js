

export const getQuickSortAnimations = array => {
    const animations = [];
    if (array.length <= 1) return array;
     quicksort(array, 0, array.length - 1,animations);
    return animations;
};

function swap(items, leftIndex, rightIndex){
    var temp = items[leftIndex];
    items[leftIndex] = items[rightIndex];
    items[rightIndex] = temp;
}

function quicksort(arr,start,end,animations)
{
    if(start>=end)
    return;

    let index = partition(arr,start,end,animations);
    quicksort(arr,start,index-1,animations); 
    quicksort(arr,index+1,end,animations);
}

function partition(arr,start,end,animations)
{
    let  pivotIndex = start;
    let pivotvalue = arr[end];

    animations.push([end,true]);

    for(let i=start;i<end;i++)
    {
        animations.push([pivotIndex,i]);
        if(arr[i]<pivotvalue)
        {
            animations.push([pivotIndex,i,arr[pivotIndex],arr[i]]);
            swap(arr,i,pivotIndex);
            pivotIndex++;
        }       
    }

    animations.push([pivotIndex,end,arr[pivotIndex],arr[end]]);
    swap(arr,pivotIndex,end);
    return pivotIndex;
}
