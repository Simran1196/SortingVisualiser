
export const getBubbleSortAnimations = array => {
    const animations = [];
    if (array.length <= 1) return array;
     bubbleSort(array,animations);
    return animations;
};

function bubbleSort(arr,animations)
{
    for(let i=0;i<arr.length;i++)
    {
        for(let j=i+1;j<arr.length;j++)
        {
            animations.push([i,j]);
            if(arr[i]>arr[j])
            {
                animations.push([i,j,arr[i],arr[j]]);
                swap(arr,i,j);
            }
            else
            animations.push([i,j,true]);
        }
    }
}

function swap(arr,i,j)
{
    let t=arr[i];
    arr[i]=arr[j];
    arr[j]=t;
}
