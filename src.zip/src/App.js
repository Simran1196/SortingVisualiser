import React from 'react';
import logo from './logo.svg';
import './App.css';
import SortingVisualiser from './SortingVisualiser/SortingVisualiser'

function App() {
  return (
    <div className="App">
      <SortingVisualiser></SortingVisualiser>
     </div>
  );
}

export default App;

//export default is used to export a single class, function or primitive from a script file.
/*
export default class HelloWorld1 extends React.Component {
  render() {
    return <p>Hello, world!</p>;
  }
}*/
