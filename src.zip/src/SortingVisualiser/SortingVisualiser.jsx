import React from 'react';
import { render } from 'react-dom';
import './SortingVisualiser.css';
// import * as sortingAlgorithms from '../SortingAlgorithms/SortingAlgorithms.js'
import {getMergeSortAnimations} from '../SortingAlgorithms/MergeSort.js'
import {getQuickSortAnimations} from '../SortingAlgorithms/QuickSort.js'
import {getBubbleSortAnimations} from '../SortingAlgorithms/BubbleSort.js'
import {getInsertionSortAnimations} from '../SortingAlgorithms/InsertionSort'
// Change this value for the speed of the animations.
const ANIMATION_SPEED_MS =1;

// Change this value for the number of bars (value) in the array.
const NUMBER_OF_ARRAY_BARS = 310;

// This is the main color of the array bars.
const PRIMARY_COLOR = 'turquoise';

// This is the color of array bars that are being compared throughout the animations.
const SECONDARY_COLOR = 'red';

const TWOBARS_COLOR = 'green';

//export default is used to export a single class, function or primitive from a script file.
export default class SortingVisualiser extends React.Component
{
    /*The constructor is a method used to initialize an object's state in a class.
     It automatically called during the creation of an object in a class.
    The concept of a constructor is the same in React. 
    The constructor in a React component is called before the component is mounted.
     When you implement the constructor for a React component, you need to call super(props) method before any other statement.
      If you do not call super(props) method, this.props will be undefined in the constructor and can lead to bugs.*/
    constructor(props)
    {
         super(props);
         /*The state object is where you store property values that belongs to the component.
        When the state object changes, the component re-renders.*/
         this.state = {
             array : [],
         };
    }


componentDidMount()
{
    this.resetArray();
}

resetArray()
{
    //const is a signal that the variable won’t be reassigned.
    const array = [];
    //let is a signal that the variable may be reassigned.
    for(let i=0;i<NUMBER_OF_ARRAY_BARS;i++)
    {
       array.push(randomIntFromIntrervals(5,730)); 
    }
    //setState is the API method provided with the library so that the user is able to define and manipulate state over time.
    this.setState({array});
}

// mergeSort()
// {
//   const javaScritSortedArray = this.state.array.slice().sort(function(a, b){return a-b});
//   const sortedArray = sortingAlgorithms.mergeSort(this.state.array);

//   console.log(arrayEqual(sortedArray,javaScritSortedArray));

// }

mergeSort() {
  const animations = getMergeSortAnimations(this.state.array);
  const arrayBars = document.getElementsByClassName('array-bar');

  for (let i = 0; i < animations.length; i++) {
    const isColorChange = i % 3 !== 2;
    if (isColorChange) {
      const [barOneIdx, barTwoIdx] = animations[i];
      const barOneStyle = arrayBars[barOneIdx].style;
      const barTwoStyle = arrayBars[barTwoIdx].style;
      const color = i % 3 === 0 ? SECONDARY_COLOR : PRIMARY_COLOR;
      setTimeout(() => {
        barOneStyle.backgroundColor = color;
        barTwoStyle.backgroundColor = color;
      }, i * ANIMATION_SPEED_MS);
    } else {
      setTimeout(() => {
        const [barOneIdx, newHeight] = animations[i];
        const barOneStyle = arrayBars[barOneIdx].style;
        barOneStyle.height = `${newHeight}px`;
      }, i * ANIMATION_SPEED_MS);
    }
  }
}

quickSort(){
  const  animations = getQuickSortAnimations(this.state.array);
  const arrayBars = document.getElementsByClassName('array-bar');

  for (let i = 0; i < animations.length; i++) {
    
    if(animations[i].length==2 && animations[i][1]==true)
    {
      const barPivotstyle = arrayBars[animations[i][0]].style;
      setTimeout(() => {
        barPivotstyle.backgroundColor = SECONDARY_COLOR;
      }, i * ANIMATION_SPEED_MS);
    }

    else if(animations[i].length==2)
    {
      const barOnestyle = arrayBars[animations[i][0]].style;
      const barTwostyle = arrayBars[animations[i][1]].style;
      setTimeout(() => {
        barOnestyle.backgroundColor = PRIMARY_COLOR;
        barTwostyle.backgroundColor = PRIMARY_COLOR ;  
      }, i * ANIMATION_SPEED_MS);
    }
    else
    {
      const barOnestyle = arrayBars[animations[i][0]].style;
      const h1 = animations[i][2];
      const barTwostyle = arrayBars[animations[i][1]].style;
      const h2 = animations[i][3];
      setTimeout(() => {
         barOnestyle.backgroundColor =PRIMARY_COLOR;
        barTwostyle.backgroundColor = PRIMARY_COLOR;
        barOnestyle.height = `${h2}px`;
        barTwostyle.height = `${h1}px`;
      }, i * ANIMATION_SPEED_MS);

      setTimeout(() => {
        barOnestyle.backgroundColor =PRIMARY_COLOR;
       barTwostyle.backgroundColor = PRIMARY_COLOR;
       barOnestyle.height = `${h2}px`;
       barTwostyle.height = `${h1}px`;
     }, i * ANIMATION_SPEED_MS);
    }

    }
  }

  bubbleSort()
{
  const  animations = getBubbleSortAnimations(this.state.array);
 
  for(let i=0;i<animations.length;i++)
  {
    const arrayBars = document.getElementsByClassName('array-bar');

    if(animations[i].length==2)
    {
      const barOnestyle = arrayBars[animations[i][0]].style;
      const barTwostyle = arrayBars[animations[i][1]].style;

      setTimeout(() => {
        barOnestyle.backgroundColor = SECONDARY_COLOR;
        barTwostyle.backgroundColor = SECONDARY_COLOR;
      }, i * ANIMATION_SPEED_MS);
    }
    else if(animations[i].length==3)
    {
      const barOnestyle = arrayBars[animations[i][0]].style;
      const barTwostyle = arrayBars[animations[i][1]].style;
      setTimeout(() => {
        barOnestyle.backgroundColor = PRIMARY_COLOR;
        barTwostyle.backgroundColor = PRIMARY_COLOR;
      }, i * ANIMATION_SPEED_MS);
    }
    else
    {
      const barOnestyle = arrayBars[animations[i][0]].style;
      const h1 = animations[i][2];
      const barTwostyle = arrayBars[animations[i][1]].style;
      const h2 = animations[i][3];
      setTimeout(() => {
        barOnestyle.backgroundColor = PRIMARY_COLOR;
        barTwostyle.backgroundColor = PRIMARY_COLOR;
        barOnestyle.height = `${h2}px`;
        barTwostyle.height = `${h1}px`;
      }, i * ANIMATION_SPEED_MS);
    }
  }

}

insertionSort()
{
  const  animations = getInsertionSortAnimations(this.state.array);
  const arrayBars = document.getElementsByClassName('array-bar');

  for (let i = 0; i < animations.length; i++)
  {
   if(animations[i].length==1)
   {
    const barPivotstyle = arrayBars[animations[i][0]].style;
    setTimeout(() => {
      barPivotstyle.backgroundColor = SECONDARY_COLOR;
    }, i * ANIMATION_SPEED_MS);
   }
   else if(animations[i].length==2)
   {
     
      const barOnestyle = arrayBars[animations[i][0]].style;
      const height = animations[i][1];
      setTimeout(() => {
        barOnestyle.backgroundColor = PRIMARY_COLOR;
        barOnestyle.height = `${height}px`;
      }, i * ANIMATION_SPEED_MS);
     
   }
   else if(animations[i].length==3)
   {
     let col = animations[i][2]==true?TWOBARS_COLOR:PRIMARY_COLOR;

    const barOnestyle = arrayBars[animations[i][0]].style;
    setTimeout(() => {
        barOnestyle.backgroundColor =col;
    }, i * ANIMATION_SPEED_MS);
   }
  
  }

}

//to update the value over time.
render()
{
    const {array} = this.state;
    return (
        <div className="array-container">
          {array.map((value, idx) => (
            <div
            className="array-bar"
            key={idx}
            style={{
              height: `${value}px`,

            }}></div>
          ))}
          <button onClick={() => this.resetArray()}>Generate New Array!!</button>
          <button onClick={() => this.mergeSort()}>Merge Sort</button>
          <button onClick={() => this.quickSort()}>Quick Sort</button>
          <button onClick={() => this.heapSort()}>Heap Sort</button>
          <button onClick={() => this.bubbleSort()}>Bubble Sort</button>
          <button onClick={() => this.insertionSort()}>Insertion Sort</button>
         
        </div>
      );
}
}


function randomIntFromIntrervals(min, max) {
    // min and max included
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

  function arrayEqual(arr1,arr2)
  {
      if(arr1.length != arr2.length)
      return false;

      for( let i=0;i<arr2.length;i++)
      {
        if(arr1[i]!=arr2[i])
        return false;
      }

      return true;
  }
  